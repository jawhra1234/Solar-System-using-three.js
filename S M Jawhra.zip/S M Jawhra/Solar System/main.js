// Wait for THREE to load
window.addEventListener('load', function() {
  if (typeof THREE === 'undefined') {
    console.error('THREE.js failed to load');
    return;
  }

  const scene = new THREE.Scene();

  // Texture loader
  const loader = new THREE.TextureLoader();
  
  // Declare starField variable
  let starField = null;

  // Background - use your stars texture or fallback to procedural
  loader.load('stars.jpg', function(texture) {
    scene.background = texture;
  }, undefined, function(error) {
    console.log('Stars texture not found, using procedural starfield');
    // Fallback procedural starfield
    const starsGeometry = new THREE.BufferGeometry();
    const starsMaterial = new THREE.PointsMaterial({ color: 0xFFFFFF, size: 2 });
    
    const starsVertices = [];
    for (let i = 0; i < 10000; i++) {
      const x = (Math.random() - 0.5) * 2000;
      const y = (Math.random() - 0.5) * 2000;
      const z = (Math.random() - 0.5) * 2000;
      starsVertices.push(x, y, z);
    }
    
    starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starsVertices, 3));
    starField = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(starField);
  });

  // Camera
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
  camera.position.set(0, 10, 50);

  // Renderer
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  // Lighting
  const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
  scene.add(ambientLight);
  
  const sunLight = new THREE.PointLight(0xffffff, 2, 1000);
  sunLight.position.set(0, 0, 0);
  scene.add(sunLight);

  // Create planets data with texture paths
  const planetsData = [
    { name: 'Sun', radius: 5, distance: 0, speed: 0, texture: 'sun.jpg', color: 0xFDB813 },
    { name: 'Mercury', radius: 0.4, distance: 8, speed: 0.04, texture: 'mercury.jpg', color: 0x8C7853 },
    { name: 'Venus', radius: 0.7, distance: 11, speed: 0.03, texture: 'venus.jpg', color: 0xFFC649 },
    { name: 'Earth', radius: 0.8, distance: 15, speed: 0.02, texture: 'earth.jpg', color: 0x6B93D6 },
    { name: 'Mars', radius: 0.6, distance: 20, speed: 0.018, texture: 'mars.jpg', color: 0xC1440E },
    { name: 'Jupiter', radius: 2.5, distance: 30, speed: 0.013, texture: 'jupiter.jpg', color: 0xD8CA9D },
    { name: 'Saturn', radius: 2.1, distance: 40, speed: 0.009, texture: 'saturn.jpg', color: 0xFAD5A5 },
    { name: 'Uranus', radius: 1.5, distance: 50, speed: 0.006, texture: 'uranus.jpg', color: 0x4FD0E7 },
    { name: 'Neptune', radius: 1.4, distance: 60, speed: 0.005, texture: 'neptune.jpg', color: 0x4B70DD }
  ];

  const planets = [];
  const planetAngles = [];
  let isPaused = false;

  // Create planets
  planetsData.forEach((planetData, index) => {
    const geometry = new THREE.SphereGeometry(planetData.radius, 32, 32);
    let material;
    
    // Try to load texture, fallback to color if texture fails
    loader.load(planetData.texture, function(texture) {
      if (planetData.name === 'Sun') {
        material = new THREE.MeshBasicMaterial({ 
          map: texture,
          emissive: planetData.color,
          emissiveIntensity: 0.2
        });
      } else {
        material = new THREE.MeshStandardMaterial({ map: texture });
      }
      planets[index].mesh.material = material;
    }, undefined, function(error) {
      console.log(`Texture not found for ${planetData.name}, using color fallback`);
      // Fallback to color material if texture fails
      if (planetData.name === 'Sun') {
        material = new THREE.MeshBasicMaterial({ 
          color: planetData.color,
          emissive: planetData.color,
          emissiveIntensity: 0.3
        });
      } else {
        material = new THREE.MeshStandardMaterial({ color: planetData.color });
      }
      planets[index].mesh.material = material;
    });
    
    // Create planet with initial color material
    if (planetData.name === 'Sun') {
      material = new THREE.MeshBasicMaterial({ 
        color: planetData.color,
        emissive: planetData.color,
        emissiveIntensity: 0.3
      });
    } else {
      material = new THREE.MeshStandardMaterial({ color: planetData.color });
    }
    
    const planet = new THREE.Mesh(geometry, material);
    
    // Initial position
    planet.position.x = planetData.distance;
    planets.push({ mesh: planet, data: planetData });
    planetAngles.push(Math.random() * Math.PI * 2); // Random starting angle
    
    scene.add(planet);

    // Add Saturn's rings
    if (planetData.name === 'Saturn') {
      const ringGeometry = new THREE.RingGeometry(2.5, 4, 32);
      const ringMaterial = new THREE.MeshBasicMaterial({ 
        color: 0xC4B5A0, 
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.6 
      });
      const rings = new THREE.Mesh(ringGeometry, ringMaterial);
      rings.rotation.x = Math.PI / 2;
      planet.add(rings);
    }
  });

  // Create speed control UI
  function createSpeedControls() {
    const speedControlsDiv = document.getElementById('speedControls');
    
    planetsData.forEach((planetData, index) => {
      if (planetData.name === 'Sun') return; // Skip sun
      
      const controlGroup = document.createElement('div');
      controlGroup.className = 'control-group';
      
      const label = document.createElement('label');
      label.textContent = planetData.name;
      
      const slider = document.createElement('input');
      slider.type = 'range';
      slider.min = '0';
      slider.max = '0.1';
      slider.step = '0.001';
      slider.value = planetData.speed;
      slider.id = `speed-${planetData.name.toLowerCase()}`;
      
      const speedDisplay = document.createElement('div');
      speedDisplay.className = 'speed-display';
      speedDisplay.textContent = `Speed: ${planetData.speed.toFixed(3)}`;
      
      slider.addEventListener('input', function() {
        const newSpeed = parseFloat(this.value);
        planetData.speed = newSpeed;
        speedDisplay.textContent = `Speed: ${newSpeed.toFixed(3)}`;
      });
      
      controlGroup.appendChild(label);
      controlGroup.appendChild(slider);
      controlGroup.appendChild(speedDisplay);
      speedControlsDiv.appendChild(controlGroup);
    });
  }

  // Pause/Resume functionality
  const pauseBtn = document.getElementById('pauseBtn');
  pauseBtn.addEventListener('click', function() {
    isPaused = !isPaused;
    if (isPaused) {
      this.textContent = 'Resume Animation';
      this.classList.add('paused');
    } else {
      this.textContent = 'Pause Animation';
      this.classList.remove('paused');
    }
  });

  // Mouse controls
  let mouseX = 0;
  let mouseY = 0;
  let targetX = 0;
  let targetY = 0;

  document.addEventListener('mousemove', (event) => {
    mouseX = (event.clientX / window.innerWidth) * 2 - 1;
    mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
  });

  // Animation loop
  function animate() {
    requestAnimationFrame(animate);

    if (!isPaused) {
      // Update planet positions
      planets.forEach((planet, index) => {
        if (planet.data.distance > 0) { // Don't move the sun
          planetAngles[index] += planet.data.speed;
          planet.mesh.position.x = Math.cos(planetAngles[index]) * planet.data.distance;
          planet.mesh.position.z = Math.sin(planetAngles[index]) * planet.data.distance;
          
          // Rotate planets on their axis
          planet.mesh.rotation.y += 0.01;
        }
      });

      // Rotate star field slowly (only if it exists)
      if (starField) {
        starField.rotation.y += 0.0002;
      }
    }

    // Smooth camera movement based on mouse (works even when paused)
    targetX = mouseX * 0.3;
    targetY = mouseY * 0.3;
    
    camera.position.x += (targetX * 100 - camera.position.x) * 0.02;
    camera.position.y += (targetY * 50 + 10 - camera.position.y) * 0.02;
    camera.lookAt(0, 0, 0);

    renderer.render(scene, camera);
  }

  // Handle window resize
  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // Initialize speed controls
  createSpeedControls();

  animate();
});